#ifndef EXP_HPP_
#define EXP_HPP_

#include <vector>
#include <string>

struct expresionstruct {
  std::string str;
  std::vector<int> trues;
  std::vector<int> falses;
  std::vector<int> exits;
  std::vector<int> continues;
};

#endif /* EXP_HPP_ */
